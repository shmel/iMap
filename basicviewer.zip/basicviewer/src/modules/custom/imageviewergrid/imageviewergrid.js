/**
 * Created by shmel on 5/6/14.
 */
define(["dojo/_base/declare",
    "dojo/dom-construct",
    "dijit/_WidgetBase",
    "dojo/on",
    "dijit/registry",
    "dojo/ready",
    "dojo/_base/lang",
    "dojo/_base/connect",
    "dijit/layout/ContentPane",
    "dojo/dom-class",
    "dojo/dom-style",
    "dojo/_base/fx",
    "dojo/_base/lang",
    "dojo/_base/array",
    "dojo/_base/Deferred",
    "../../core/utilities/maphandler",
    "dojo/topic",
    "dijit/_TemplatedMixin",
    "dojo/text!./imageviewergrid.html",
    "dojo/json",
    "esri/layers/ArcGISDynamicMapServiceLayer",
    "esri/layers/FeatureLayer",
    "esri/tasks/Geoprocessor",
    "esri/toolbars/draw",
    "esri/graphic",
    "esri/symbols/SimpleMarkerSymbol",
    "esri/symbols/SimpleLineSymbol",
    "esri/renderers/SimpleRenderer",
    "dojo/_base/Color",
    "dijit/form/Button",
    "dijit/form/ToggleButton",
    "dstore/Memory",
    "dstore/Trackable",
    "dstore/Tree",
    "dgrid/OnDemandGrid",
    "dgrid/Tree",
    "dgrid/Selection",
    "dojo/on",
    "esri/map",
    "dojo/dom",
    "dojo/number",
    "../../core/attributetable/attributetable",
    "dojo/parser",
    "xstyle/css!./css/imageviewergrid.css",
    "xstyle/css!dgrid/css/dgrid.css"],

    function(declare,
             domConstruct,
             WidgetBase,
             dojoOn,
             registry,
             ready,
             lang,
             connect,
             ContentPane,
             domClass,
             domStyle,
             fxer,
             language,
             array,
             Deferred,
             mapHandler, topic, TemplatedMixin, template,
             json , ArcGISDynamicMapServiceLayer, FeatureLayer ,
             Geoprocessor, Draw, Graphic, SimpleMarkerSymbol, SimpleLineSymbol,
             SimpleRenderer, Color, Button, ToggleButton, Memory, Trackable, TreeStoreMixin, OnDemandGrid, Tree, Selection, on, Map, dom, dojoNum, AttributeTable
        ){
        return declare([WidgetBase, TemplatedMixin],{
            //*** Properties needed for this style of module
            // The template HTML fragment (as a string, created in dojo/text definition above)

            templateString: template
            // The CSS class to be applied to the root node in our template

            , baseClass: "ImageViewerDiv"
            // The ESRI map object to bind to the TOC. Set in constructor
            , map: null
            , toolbar: null
            , AttWidget : null
            , drawHandler: null
            , wwresultsHandler: null
            , waterresultsHandler: null




            //*** Creates
            , constructor: function(args) {
                // safeMixin automatically sets the properties above that are passed in from the toolmanager.js
                declare.safeMixin(this,args);
                // mapHandler is a singleton object that you can require above and use to get a reference to the map.
                this.map = mapHandler.map;
            }

            //The widget has been added to the DOM, though not visible yet. This is the recommended place to do most of the module's work
            , postCreate: function () {
                this.inherited(arguments);
            }

            /* A standard module event handler. In the postcreate and startup handlers,
             * you can assume the module has been created. You don't need to add a handler function if you are not writing code in it.
             */
            , startup: function () {
              //Build out the DataGrid

                var testData  = [ {"folder": "0042_W&SMains_BannisterNeighborhood_Contract#35", "type": "folder"},
                 {"folder": "0046_W&SMains_BannisterNeighborhood", "type": "folder"},
                 {"folder": "1459_WandSMains_Bannister", "type": "folder"}]

                 var testSubData  =   [
                 {
                 "associated": "True",
                 "img_path": "\\\\adams\\charlesutils\\mrsid\\boxA\\0042_W&SMains_BannisterNeighborhood_Contract#35\\000191.sid",
                 "img_id": "000191",
                 "title_page": "Title Page",
                 "img_lu_ins_id": null,
                 "folder": "0042_W&SMains_BannisterNeighborhood_Contract#35",
                 "type": "image"
                 },
                 {
                 "associated": "True",
                 "img_path": "\\\\adams\\charlesutils\\mrsid\\boxA\\0042_W&SMains_BannisterNeighborhood_Contract#35\\000192.sid",
                 "img_id": "000192",
                 "title_page": "",
                 "img_lu_ins_id": null,
                 "folder": "0042_W&SMains_BannisterNeighborhood_Contract#35",
                 "type": "image"
                 },
                     {
                         "associated": "True",
                         "img_path": "\\\\adams\\charlesutils\\mrsid\\boxA\\0046_W&SMains_BannisterNeighborhood\\000244.sid",
                         "img_id": "000244",
                         "title_page": "Title Page",
                         "img_lu_ins_id": null,
                         "folder": "0046_W&SMains_BannisterNeighborhood"
                     },
                     {
                         "associated": "True",
                         "img_path": "\\\\adams\\charlesutils\\mrsid\\boxA\\0046_W&SMains_BannisterNeighborhood\\000245.sid",
                         "img_id": "000245",
                         "title_page": "",
                         "img_lu_ins_id": null,
                         "folder": "0046_W&SMains_BannisterNeighborhood"
                     },
                     {
                         "associated": "True",
                         "img_path": "\\\\adams\\charlesutils\\mrsid\\boxA\\0046_W&SMains_BannisterNeighborhood\\000246.sid",
                         "img_id": "000246",
                         "title_page": "",
                         "img_lu_ins_id": null,
                         "folder": "0046_W&SMains_BannisterNeighborhood"
                     }]

                /*var testData  =   [
                    {"folder": "0042_W&SMains_BannisterNeighborhood_Contract#35", "type": "folder"},
                {
                "associated": "True",
                "img_path": "\\\\adams\\charlesutils\\mrsid\\boxA\\0042_W&SMains_BannisterNeighborhood_Contract#35\\000191.sid",
                "img_id": "000191",
                "title_page": "Title Page",
                "img_lu_ins_id": null,
                "folder": "0042_W&SMains_BannisterNeighborhood_Contract#35",
                "type": "image"
                },
                {
                "associated": "True",
                "img_path": "\\\\adams\\charlesutils\\mrsid\\boxA\\0042_W&SMains_BannisterNeighborhood_Contract#35\\000192.sid",
                "img_id": "000192",
                "title_page": "",
                "img_lu_ins_id": null,
                "folder": "0042_W&SMains_BannisterNeighborhood_Contract#35",
                "type": "image"
                },
                    {"folder": "0046_W&SMains_BannisterNeighborhood", "type": "folder"},
                    {"folder": "1459_WandSMains_Bannister", "type": "folder"}
                ]*/


                var dMemstore = new (declare([Memory, Trackable, TreeStoreMixin]))({
                    data: createData(testData,testSubData)
                    /*getChildren: function (parent) {
                        //return  parent.children || {}
                        return function createChildStore(){
                            childStore = new (declare([Memory, Trackable]))({
                                data: parent.children
                            });
                        }


                    },
                    mayHaveChildren: function (parent) {
                        return !!parent.children;
                    }*/
                });


// Instantiate grids
                var grid = new (declare([OnDemandGrid, Tree]))({
                    //collection: dMemstore.getRootCollection(),
                    collection: dMemstore.filter({'hasChildren': true}),
                    columns: {
                        folder: {
                            label: 'folder',
                            renderExpando: true
                        }
                    }
                }, 'plansetsGrid');

                //Update rows that have Assocation


                grid.on(".dgrid-row:click", function (evt) {
                    var row = grid.row(evt);
                    ID = row.data.ID; //this is always the last record in the grid
                    alert(ID);
                });

                grid.startup();


                function createData (folders, images) {
                   //Sample Data
                   /* var data = [];
                    var column;
                    var i;
                    for (i = 0; i < 50; i++) {
                        data.push({});
                        for (column in { First_Name: 1, Last_Name: 1 }) {
                            data[i].id = i;
                            data[i][column] = column + '_' + (i + 1);
                        }
                        if (i > 1) {
                            data[i].hasChildren = false;
                            data[i].parent = i % 2;
                        }
                    }
                    return data;*/

                    var data = [];

                    var column;
                    var i;
                    //Loop Through Folders
                    for (i = 0; i < folders.length; i++) {
                        //Add Folder to Data Store
                        data.push({});
                        data[data.length - 1].folder = folders[i].folder;
                        data[data.length - 1].id = data.length - 1;
                        data[data.length - 1].type = 'folder';
                        data[data.length - 1].hasChildren = true;
                        var parentIdx = data.length - 1
                        var parentFolder = folders[i].folder;

                        var subData = [];

                        //Filter Images to Image for just this folder
                        var selImages = images.filter(function (img) {
                            return img.folder == parentFolder;
                        });
                        //if selImages.length > 0
                        //Loop through Images and add to store
                        for (aImg = 0; aImg < selImages.length; aImg++) {
                            data.push({});
                            data[data.length - 1].hasChildren = false;
                            data[data.length - 1].id = data.length - 1;
                            data[data.length - 1].parent = parentIdx;
                            data[data.length - 1].img_id = selImages[aImg].img_id;
                            data[data.length - 1].title_page = selImages[aImg].title_page;
                            data[data.length - 1].type = 'image';
                            if(data[data.length - 1].title_page == 'Title Page') {
                                data[data.length - 1].folder = selImages[aImg].img_id + " - Title Page";
                            }
                            else {
                                data[data.length - 1].folder = selImages[aImg].img_id;
                            }
                        }

                       // data[data.length - 1].children = subData;
                    }
                    return {
                        identifier: 'id',
                        items: data
                    } ;
                }
            }
            , LoadFolders: function(){

            }
            , NewFunctionHere: function(){

            }

        });
    });